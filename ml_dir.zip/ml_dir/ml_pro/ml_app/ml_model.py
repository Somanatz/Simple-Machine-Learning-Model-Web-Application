# mlapp/ml_model.py
import pickle
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_regression

def train_model():
    X, y = make_regression(n_samples=100, n_features=1, noise=0.1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LinearRegression()
    model.fit(X_train, y_train)
    with open('ml_app/model.pkl', 'wb') as f:
        pickle.dump(model, f)
