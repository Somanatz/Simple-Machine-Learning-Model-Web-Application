from django.contrib import admin
from ml_app.models import Prediction
# Register your models here.
admin.site.register(Prediction)
