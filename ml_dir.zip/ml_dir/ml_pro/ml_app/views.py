from django.shortcuts import render

# Create your views here.
# mlapp/views.py
import pickle
from django.http import JsonResponse

from django.http import JsonResponse
from .models import Prediction
import pickle

def predict(request):
    # Load model
    with open('ml_app/model.pkl', 'rb') as f:
        model = pickle.load(f)

    try:
        # Input example: ?value=10
        value = float(request.GET.get('value', 0))

        # Make a prediction
        prediction = model.predict([[value]])

        # Save to database
        Prediction.objects.create(input_value=value, predicted_value=prediction[0])

        return JsonResponse({'prediction': prediction[0]})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

def index(request):
    return render(request, 'index.html')

from .models import Prediction

def view_predictions(request):
    predictions = Prediction.objects.all().order_by('-timestamp')  # Latest first
    return render(request, 'view_predictions.html', {'predictions': predictions})
