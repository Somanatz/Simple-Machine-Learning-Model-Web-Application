from django.db import models

# Create your models here.
class Prediction(models.Model):
    input_value = models.FloatField()
    predicted_value = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Input: {self.input_value}, Prediction: {self.predicted_value}"
