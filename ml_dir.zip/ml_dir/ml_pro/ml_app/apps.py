from django.apps import AppConfig


class MlAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ml_app"
